

<?php $__env->startSection('content'); ?>
    <h6 class="text-end m-4 fw-bold  ">تـفـاصـيـل الـمـؤسـسـة </h6>
    <div class="container-fluid  px-4">
        <div class="text-center rounded   pb-3">
            <div class="table-responsive bg-secondary1 p-4">
                <table class="table text-end  table-striped table-borderless  align-middle  table-hover mb-0 ">
                    <thead>
                        <tr>
                            <th class="text-white px-2 w-25">الـمـؤسـسـة</th>
                            <th class="text-white px-2">الـوصـف</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr hidden></tr>
                        <tr>
                            <td class="px-3 ">اســم </td>
                            <td class="px-3"><?php echo e($organization->title); ?></td>
                        </tr>
                        <tr>
                            <td class="px-3 ">الـحـالـة</td>
                            <?php if($organization->state == 0): ?>
                                <td class="px-3">قـيـد الأنـتـظـار</td>
                            <?php elseif($organization->state == 1): ?>
                                <td class="px-3">فـعـالـة</td>
                            <?php elseif($organization->state == -1): ?>
                                <td class="px-3">مـحـجـوبـة</td>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <td class="px-3 ">بـيـانـات الأتـصـال</td>
                            <td class="px-3"><?php echo e($organization->contact_statement); ?></td>
                        </tr>
                        <tr>
                            <td class="px-3 "> السجل التجاري</td>

                            <td class="px-3"><a target="_blank" href="http://127.0.0.1:8000/uploads/<?php echo e($organization->trade_document); ?>">
                                    <?php echo e($organization->trade_document); ?> </a></td>

                        </tr>
                        <tr>
                            <td class="px-3 ">الـوصــف</td>
                            <td class="px-3"><?php echo e($organization->description); ?></td>
                        </tr>

                    </tbody>

                </table>
            </div>
            <div class="mt-3 p-0 d-flex justify-content-between">
                <form action="<?php echo e(route('foundations.update', $organization->id)); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <?php if($organization->state == 0): ?>
                        <input type="text" name="state" id="" value="1" hidden>
                        <button type="submit" class="btn btn-sm mybtn-secondary fw-bold px-5 fs-6 m-2">تـأكـيـد</button>

                        
                    <?php elseif($organization->state == 1): ?>
                        <input type="text" name="state" id="" value="-1" hidden>
                        <button type="submit" class="btn btn-sm mybtn-secondary fw-bold px-5 fs-6 m-2"
                            href="">حــجــب</button>
                    <?php elseif($organization->state == '-1'): ?>
                        <input type="text" name="state" id="" value="1" hidden>
                        <button type="submit" class="btn btn-sm mybtn-secondary fw-bold px-5 fs-6 m-2"
                            href="">تـفـعـيـل</button>
                    <?php endif; ?>

                </form>


                <a class="btn btn-sm btn-dark  px-3  m-2" href="javascript:history.back()">رجـوع </a>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/munaqasatmloud/foundation/deteails.blade.php ENDPATH**/ ?>