



<?php $__env->startSection('content'); ?>
<h6 class="text-end mx-4 mt-3  text-while f-18">  الـمـسـتـخـدمـيـن</h6>
<nav class="mt-1 mx-4">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"></li>
      <li class="breadcrumb-item">الحسابات</li>
      <li class="breadcrumb-item active">المستخدمون</li>
    </ol>
  </nav>
<div class="container-fluid  px-4">
    <div class="bg-secondary text-center rounded p-4">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <a href="<?php echo e(route('account.back.users.create')); ?>" class="mb-0 fw-bold  text-white btn btn-sm btn-primary px-3 py-1">أضافة مـسـتـخـدم</a>
           
        </div>
        <div class="table-responsive">
            <table class="table text-start align-middle table-bordered table-hover mb-0 text-center">
                <thead>
                    <tr class="text-white ">
                       <th scope="col">اسـم مـسـتـخـدم</th>
                        <th scope="col">عـمـلـيـات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($user->username); ?></td>
                      <td>
                        <a class="btn btn-sm  fw-bold " href="<?php echo e(route('account.back.users.show', $user->id)); ?>"><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                        <a class="btn btn-sm  fw-bold " href="<?php echo e(route('account.back.users.edit', $user->id)); ?>"><i class="bi bi-pencil-fill fw-bold  f-18"></i></a>
                        <a class="btn btn-sm fw-bold " href="<?php echo e(route('account.back.users.delete', $user->id)); ?>"><i class="bi bi-trash fw-bold text-primary f-18"></i></a>
                       </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                    
                  </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/account/users/index.blade.php ENDPATH**/ ?>