

<?php $__env->startSection('content'); ?>
    <h6 class="text-end mx-4 mt-3  text-while f-18"> الـمـؤسـسـات</h6>
    <div class="container-fluid  px-4 ">
        <ul class="nav nav-pills rounded my-3 w-100 bg-secondary1 d-flex justify-content-between p-0" id="pills-tab"
            role="tablist">
            <li class="nav-item w-33 m-0 p-0" role="presentation ">
                <button class="nav-link active w-100 fw-bold pt-10p" id="pills-home-tab" data-bs-toggle="pill"
                    data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                    aria-selected="true">قـيـد الأنـتــظــار</button>
            </li>
            <li class="nav-item w-33" role="presentation">
                <button class="nav-link w-100 fw-bold pt-10p" id="pills-profile-tab " data-bs-toggle="pill"
                    data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile"
                    aria-selected="false">المــفــعــلــة</button>
            </li>
            <li class="nav-item w-33" role="presentation">
                <button class="nav-link w-100 fw-bold pt-10p" id="pills-contact-tab" data-bs-toggle="pill"
                    data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact"
                    aria-selected="false">الـمـحـجـوبــة</button>
            </li>
        </ul>
        <div class="tab-content" id="pills-tabContent">


            
            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                <div class="container-fluid pt-2 p-0">
                    <div class="bg-secondary1 text-center rounded p-4">

                        <div class="table-responsive">
                            <table
                                class="table text-start align-middle table-striped table-borderless table-hover mb-0 text-center">
                                <thead>
                                    <tr class="text-white">
                                        <th scope="col">اسـم </th>
                                        
                                        <th scope="col">بـيـانـات الأتـصـال</th>
                                        <th scope="col">رقم السحل التجاري</th>
                                        <th scope="col">عـمـلـيـات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr hidden></tr>
                                    <?php $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td class="fw-bold"><?php echo e($org->title); ?></td>
                                            <td class="fw-bold"><?php echo e($org->contact_statement); ?></td>
                                            <td class="fw-bold"><?php echo e($org->trade_document); ?></td>
                                            <td class="fw-bold">
                                                <a class="btn btn-sm fw-bold"
                                                    href="<?php echo e(route('foundations.show', ['foundation' => $org->id])); ?>">
                                                    <i class="bi bi-info-circle fw-bold f-18"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


            
            <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                <div class="container-fluid pt-2 p-0">
                    <div class="bg-secondary1 text-center rounded p-4">

                        <div class="table-responsive">
                            <table
                                class="table text-start table-striped table-borderless align-middle table-hover mb-0 text-center">
                                <thead>
                                    <tr class="text-white">
                                        <th scope="col">اسـم </th>
                                        
                                        <th scope="col">بـيـانـات الأتـصـال</th>
                                        <th scope="col">رقم السحل التجاري</th>
                                        <th scope="col">عـمـلـيـات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $Effective; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td class=""><?php echo e($eff->title); ?></td>
                                            <td class=""><?php echo e($eff->contact_statement); ?></td>
                                            <td class=""><?php echo e($eff->trade_document); ?></td>
                                            <td class="">
                                                <a class="btn btn-sm fw-bold"
                                                    href="<?php echo e(route('foundations.show', ['foundation' => $eff->id])); ?>">
                                                    <i class="bi bi-info-circle fw-bold f-18"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            
            <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                <div class="container-fluid pt-2 p-0">
                    <div class="bg-secondary1 text-center rounded p-4">

                        <div class="table-responsive">
                            <table
                                class="table text-start align-middle table-striped table-borderless table-hover mb-0 text-center">
                                <thead>
                                    <tr class="text-white">
                                        <th scope="col">اسـم </th>
                                        
                                        <th scope="col">بـيـانـات الأتـصـال</th>
                                        <th scope="col">رقم السحل التجاري</th>
                                        <th scope="col">عـمـلـيـات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $Blocked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td class="fw-bold"><?php echo e($blo->title); ?></td>
                                            <td class="fw-bold"><?php echo e($blo->contact_statement); ?></td>
                                            <td class="fw-bold"><?php echo e($blo->trade_document); ?></td>
                                            <td class="fw-bold">
                                                <a class="btn btn-sm fw-bold"
                                                    href="<?php echo e(route('foundations.show', ['foundation' => $blo->id])); ?>">
                                                    <i class="bi bi-info-circle fw-bold f-18"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/munaqasatmloud/foundation/foundation.blade.php ENDPATH**/ ?>