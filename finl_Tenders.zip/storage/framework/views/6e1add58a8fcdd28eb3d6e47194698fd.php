

<?php $__env->startSection('content'); ?>
    <h6 class="text-end m-4 mb-0  f-18 fw-bold"> تـفـاصـيـل الـمـقـاول</h6>
    <div class="container-fluid pt-4 px-4">
        <div class=" text-center rounded p-4 bg-white pb-3">
            <div class="table-responsive bg-secondary1">
                <table class="table text-end  table-striped table-borderless  align-middle  table-hover mb-0 ">
                    <thead>
                        <th>المقاول</th>
                        <th>الوصـف</th>
                    </thead>
                    <tbody>
                        <tr></tr>
                        <tr>
                            <th class="px-3  w-250">الإســم</th>
                            <td class="px-3 "><?php echo e($contractor->name); ?> </td>
                        </tr>
                        <tr>
                            <th class="px-3 "> الـعـنـوان </th>
                            <td class="px-3 "><?php echo e($contractor->title); ?></td>
                        </tr>
                        <tr>
                            <th class="px-3 ">الــوصــف</th>
                            <td class="px-3 "> <?php echo e($contractor->description); ?> </td>
                        </tr>
                    </tbody>

                </table>
            </div>
            <div class="mt-3 p-0 d-flex justify-content-between">
                <form action="<?php echo e(route('contractor.update', $contractor->id)); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <?php if($contractor->state == 1): ?>
                        <input type="text" name="state" id="" value="-1" hidden>
                        <button type="submit" class="btn btn-sm mybtn-secondary fw-bold   px-3  m-2">حــجــب</button>
                    <?php elseif($contractor->state == -1): ?>
                        <input type="text" name="state" id="" value="1" hidden>
                        <button type="submit" class="btn btn-sm mybtn-secondary fw-bold   px-3  m-2">تـفـعـيـل</button>
                    <?php endif; ?>
                </form>
                <a class="btn btn-sm btn-dark  px-3  m-2" href="javascript:history.back()">رجــوع</a>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/munaqasatmloud/contractors/platform/details.blade.php ENDPATH**/ ?>