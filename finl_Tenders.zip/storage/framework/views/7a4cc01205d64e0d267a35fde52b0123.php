

<?php $__env->startSection('content'); ?>
<h6 class="text-end mx-4 mt-3 fw-bold text-while f-18 ">  الـمـنـاقـصـات</h6>
<div class="container-fluid  px-4 mb-60">
    <ul class="nav nav-pills my-3 w-100 bg-secondary d-flex justify-content-between p-0" id="pills-tab" role="tablist">
        <li class="nav-item w-33 m-0 p-0" role="presentation ">
          <button  class="nav-link active w-100 fw-bold pt-10p" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">قـيـد الأعــداد</button>
        </li>
        <li class="nav-item w-33" role="presentation">
          <button class="nav-link w-100 fw-bold pt-10p" id="pills-profile-tab " data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">فــعــالــــــة</button>
        </li>
        <li class="nav-item w-33" role="presentation">
          <button class="nav-link w-100 fw-bold pt-10p" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">مــنــتــهــيــة</button>
        </li>
      </ul>
      <div class="tab-content" id="pills-tabContent">
         
        
        
        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
            <div class="container-fluid py-2 p-0 ">
                <div class="bg-secondary text-center rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <p></p>
                        
                        <a class="btn btn-sm btn-primary fw-bold px-4 py-2 m-2" href="<?php echo e(route('tender.create')); ?>">أضــافــة مـنـاقـصـة</a>
                       </div>
                    <div class="table-responsive">
                        <table class="table text-start align-middle table-bordered table-hover mb-0 text-center">
                            <thead>
                                <tr class="text-white">
                                    <th scope="col"> الـمـنـاقـصـة</th>
                                   
                                    <th scope="col">الـمـعـد </th>
                                    <th scope="col">عـمـلـيـات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $UnderPreparation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $under): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="fw-bold"> <?php echo e($under->name); ?></td>
                                    <td class="fw-bold"> <?php echo e($under->title); ?></td>
                                    <td class="fw-bold ">
                                        <?php if($under->tenderDocuments()->exists()): ?> 
                                        <a class="btn btn-sm  fw-bold" href="<?php echo e(route('notebook.show',  $under->id)); ?>"><i class="fas fa-file-contract fw-bold  f-18"></i></a>                                            
                                        <?php else: ?> 
                                        <a class="btn btn-sm  fw-bold" href="<?php echo e(route('createnote', $under->id)); ?>"><i class="fa fa-address-book fw-bold  f-18"></i></a>                                            
                                            
                                              <?php endif; ?>
                                        <a class="btn btn-sm  fw-bold" href="<?php echo e(route('tender.show', ['tender' => $under->id])); ?>"><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                                        <a class="btn btn-sm  fw-bold" href="<?php echo e(route('tender.edit', ['tender' => $under->id])); ?>"><i class="bi bi-pencil-fill fw-bold  f-18"></i></a>
                                        <a class="btn btn-sm fw-bold delete-btn" data-bs-toggle="modal" data-bs-target="#myModal<?php echo e($under->id); ?>" data-id="<?php echo e($under->id); ?>" data-name="<?php echo e($under->id); ?>"><i class="fas fa-trash-alt fw-bold text-primary f-18"></i></a>
                                        
                                    </td>
                                </tr>
                                <div style="margin-top: 15% !important" class="modal fade mt-5" id="myModal<?php echo e($under->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog ">
                                        
                                        <div class="modal-content  bg-secondary">
                                        <div class="modal-header border-0 d-flex justify-content-between w-100">
                                          <h6 class="modal-title pt-2" id="exampleModalLabel">  هــل تــريــد حــذف هـذا الـمـنـاقـصـة <?php echo e($under->name); ?>؟</h6>
                                          
                                        </div>
                                        <div class="modal-body border-0">
                                          <p>بالضغط على تأكيد سيتم حذف العنصر نهائياً.</p>
                                        </div>
                                        <div class="modal-footer border-0">
                                          <form action="<?php echo e(route('tender.destroy', $under->id)); ?>" method="post">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-primary px-4">تأكيد</button>
                                          </form>
                                          <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">إلغاء</button>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                        
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </tbody>
                        </table>
                    </div>
                </div>
            </div>
                                  
            </div>
            <script>
                $(document).ready(function() {
                  $('.delete-btn').click(function() {
                    var modalId = $(this).data('bs-target');
                    $(modalId).modal('show');
                  });
                });
              </script>

        
        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
            <div class="container-fluid py-2 p-0 ">
                <div class="bg-secondary text-center rounded p-4">
                    
                    <div class="table-responsive">
                        <table class="table text-start align-middle table-bordered table-hover mb-0 text-center">
                            <thead>
                                <tr class="text-white">
                                    <th scope="col"> الـمـنـاقـصـة</th>
                                    <th scope="col">الـمـعـد </th>
                                    <th scope="col">عـمـلـيـات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Effective; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Effe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                               
                                <tr>
                                    <td class="fw-bold"> <?php echo e($Effe->name); ?></td>
                                   
                                    <td class="fw-bold"> <?php echo e($Effe->title); ?></td>
                                    <td class="fw-bold ">
                                        <a class="btn btn-sm  fw-bold" href="<?php echo e(route('notebook.show',  $Effe->id)); ?>"><i class="fas fa-file-contract fw-bold  f-18"></i></a>                                            
                                        <a class="btn btn-sm  fw-bold " href="<?php echo e(route('tender.show', ['tender' => $Effe->id])); ?>"><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
            <div class="container-fluid py-2 p-0 ">
                <div class="bg-secondary text-center rounded p-4">
                    
                    <div class="table-responsive">
                        <table class="table text-start align-middle table-bordered table-hover mb-0 text-center">
                            <thead>
                                <tr class="text-white">
                                    <th scope="col"> الـمـنـاقـصـة</th>
                                    <th scope="col">الـمـعـد </th>
                                    <th scope="col">عـمـلـيـات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Finished; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Finish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                               
                                <tr>
                                    <td class="fw-bold"> <?php echo e($Finish->name); ?></td>
                                   
                                    <td class="fw-bold"> <?php echo e($Finish->title); ?></td>
                                    <td class="fw-bold ">
                                        <a class="btn btn-sm  fw-bold" href="<?php echo e(route('notebook.show',  $Finish->id)); ?>"><i class="fas fa-file-contract fw-bold  f-18"></i></a>                                            
                                        <a class="btn btn-sm  fw-bold " href="<?php echo e(route('tender.show', ['tender' => $Finish->id])); ?>"><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
      </div>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/tenant/tenders/offers.blade.php ENDPATH**/ ?>