

<?php $__env->startSection('content'); ?>
<h6 class="text-end m-4 text-white">تـفـاصـيـل الـمـؤسـسـة </h6>
<div class="container-fluid  px-4">
    <div class="bg-secondary text-center rounded p-4 pb-3">
        <div class="table-responsive">
            <table class="table text-center  align-middle table-bordered table-hover mb-0 ">
                    <tr>
                        <th class="text-white">الـمـؤسـسـة</th>
                        <th class="text-white">الـوصـف</th>
                    </tr>
                
                <tr>
                    <td class="px-3 ">اســم الـمـؤسـسـة</td>
                    <td class="px-3"><?php echo e($organization->title); ?></td>
                </tr>
                <tr>
                    <td class="px-3 ">الـحـالـة</td>
                    <td class="px-3"><?php echo e($organization->state); ?></td>
                </tr>
                <tr>
                    <td class="px-3 ">بـيـانـات الأتـصـال</td>
                    <td class="px-3"><?php echo e($organization->contact_statement); ?></td>
                </tr>
                <tr>
                    <td class="px-3 ">رقم السجل التجاري</td>
                    <td class="px-3"><?php echo e($organization->trade_document); ?></td>
                </tr>
                <tr>
                    <td class="px-3 ">الـوصــف</td>
                    <td class="px-3"><?php echo e($organization->description); ?></td>
                </tr>
          
               
                   </table>
        </div>
        <div class="mt-3 p-0 d-flex justify-content-between">
            <form action="<?php echo e(route('foundations.update', $organization->id)); ?>"  metdod="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <?php if($organization->state == 'قيد الأعداد'): ?>
                <input type="text" name="state" id="" value="فعالة" hidden>
            <button type="submit" class="btn btn-sm btn-primary fw-bold px-5 fs-6 m-2" href="">تـأكـيـد</button>
           
            
            <?php elseif($organization->state == 'فعالة'): ?>
            <input type="text" name="state" id="" value="محجوبة" hidden>
            <button type="submit" class="btn btn-sm btn-primary fw-bold px-5 fs-6 m-2" href="">حــجــب</button>
           <?php elseif($organization->state == 'محجوبة'): ?>
           <input type="text" name="state" id="" value="فعالة" hidden>
           <button type="submit" class="btn btn-sm btn-primary fw-bold px-5 fs-6 m-2" href="">تـفـعـيـل</button>
           
           <?php endif; ?>
               
        </form>

           
            <a class="btn btn-sm btn-dark  px-3  m-2" href="">رجـوع </a>
        </div>        
    </div>

</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/platform/foundations/deteails.blade.php ENDPATH**/ ?>