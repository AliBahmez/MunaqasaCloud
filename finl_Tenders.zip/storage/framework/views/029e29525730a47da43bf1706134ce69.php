<?php $__env->startSection('content'); ?>
<section class="section error-404 min-vh-100 d-flex flex-column align-items-center justify-content-center">
        <h1>404</h1>
        <h2>المسار غير موجود</h2>
        <a class="btn" href="<?php echo e(route('dashboard.user')); ?>">الرجوع للرئيسية</a>
        <img src="<?php echo e(asset('assets/img/not-found.svg')); ?>" class="img-fluid py-5" alt="Page Not Found">
      </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/errors/404.blade.php ENDPATH**/ ?>