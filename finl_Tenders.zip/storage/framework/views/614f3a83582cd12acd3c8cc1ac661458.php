<?php $__env->startSection('content'); ?>
<div>
    Dashboard
    <!-- Live as if you were to die tomorrow. Learn as if you were to live forever. - Mahatma Gandhi -->

    <?php
        $hasPermission = Account::hasPermission('become_tenant');
    ?>

    <?php if($hasPermission): ?>
        <p>The user has the 'become_tenant' permission.</p>
    <?php else: ?>
        <p>The user does not have the 'become_tenant' permission.</p>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/dashboard/user.blade.php ENDPATH**/ ?>