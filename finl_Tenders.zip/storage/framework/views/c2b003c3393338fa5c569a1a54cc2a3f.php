



<?php $__env->startSection('content'); ?>
    
    <!-- Sale & Revenue Start -->
    <div class="container-fluid pt-4 px-4" dir="ltr">
        <div class="row g-4">
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-line fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2 fw-bold">عـدد الـمـنـاقـصـات</p>
                        <h6 class="mb-0">1234</h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-bar fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2 fw-bold">عدد الـمـؤسـسـات</p>
                        <h6 class="mb-0">9874</h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-area fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2 fw-bold">عدد الـمـقـاولـيـن</p>
                        <h6 class="mb-0">17894</h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between py-4 px-3">
                    <i class="fa fa-chart-pie fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2 fw-bold">المناقصات المنتهي</p>
                        <h6 class="mb-0">4561</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Sale & Revenue End -->


    <!-- Recent Sales Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary text-center rounded p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h6 class="mb-0 fw-bold">مـوسـسـات قـيـد الأنتـظـار</h6>
                <a href="" class="fw-bold">عــرض الـكـل</a>
            </div>
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0 text-center">
                    <thead>
                        <tr class="text-white">
                            <!-- <th scope="col"><input class="form-check-input" type="checkbox"></th> -->
                            <th scope="col">اسـم الـمـؤسـسـة</th>
                            <th scope="col">عـنـوان الـمـؤسـسـة</th>
                            <th scope="col">بـيـانـات الأتـصـال</th>
                            <th scope="col">رقم السحل التجاري</th>
                            <th scope="col">عـمـلـيـات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="fw-bold">موسسة خير الله</td>
                            <td class="fw-bold">المكلا</td>
                            <td class="fw-bold">355123</td>
                            <td class="fw-bold">19723</td>
                            <td class="fw-bold ">
                                <a class="btn btn-sm  fw-bold " href=""><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                            </td>
                        </tr>
                        <tr>
                            <td class="fw-bold">موسسة خير الله</td>
                            <td class="fw-bold">المكلا</td>
                            <td class="fw-bold">355123</td>
                            <td class="fw-bold">19723</td>
                            <td class="fw-bold ">
                                <a class="btn btn-sm  fw-bold " href=""><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                            </td> </tr>
                        <tr>
                            <td class="fw-bold">موسسة خير الله</td>
                            <td class="fw-bold">المكلا</td>
                            <td class="fw-bold">355123</td>
                            <td class="fw-bold">19723</td>
                            <td class="fw-bold ">
                                <a class="btn btn-sm  fw-bold " href=""><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                            </td> </tr>
                        <tr>
                            <td class="fw-bold">موسسة خير الله</td>
                            <td class="fw-bold">المكلا</td>
                            <td class="fw-bold">355123</td>
                            <td class="fw-bold">19723</td>
                            <td class="fw-bold ">
                                <a class="btn btn-sm  fw-bold " href=""><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                            </td>   </tr>
                        <tr>
                            <td class="fw-bold">موسسة خير الله</td>
                            <td class="fw-bold">المكلا</td>
                            <td class="fw-bold">355123</td>
                            <td class="fw-bold">19723</td>
                            <td class="fw-bold ">
                                <a class="btn btn-sm  fw-bold " href=""><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                            </td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Recent Sales End -->


    <!-- Widgets Start -->
    <div class="container-fluid pt-4 px-4 mb-60">
        <div class="row g-4  ">

            <div class="col-sm-12 col-md-6 col-xl-8 mb-60">
                <div class="h-100 bg-secondary rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <h6 class="mb-0 fw-bold">الـمـقـاولـيـن</h6>
                        <a href="" class="fw-bold">عــرض الـكـل</a>
                    </div>
                    <div class="d-flex align-items-center border-bottom py-3">
                        <img class="rounded-circle flex-shrink-0" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                        <div class="w-100 me-2">
                            <div class="d-flex w-100 justify-content-between align-items-center">
                                <h6 class="mb-0 m-0 p-0 ">أحمد علي</h6>
                                <small class="mt-3 mb-0">
                                    <a class="btn btn-sm  fw-bold " href=""><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                                </small>
                            </div>
                            <span  class=" fw-bold mt--1 d-block mb-0">حـضـرمـوت / الـمـكـلا</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center border-bottom py-3">
                        <img class="rounded-circle flex-shrink-0" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                        <div class="w-100 me-2">
                            <div class="d-flex w-100 justify-content-between align-items-center">
                                <h6 class="mb-0 m-0 p-0 ">مـحـمـد أحمد </h6>
                                <small class="mt-3 mb-0">
                                    <a class="btn btn-sm  fw-bold " href=""><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                                </small> </div>
                            <span  class=" fw-bold mt--1 d-block mb-0">حـضـرمـوت / سـيـؤن</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center border-bottom py-3">
                        <img class="rounded-circle flex-shrink-0" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                        <div class="w-100 me-2">
                            <div class="d-flex w-100 justify-content-between align-items-center">
                                <h6 class="mb-0 m-0 p-0 ">عـبـدالـرحـمـن فـرج</h6>
                                <small class="mt-3 mb-0">
                                    <a class="btn btn-sm  fw-bold " href=""><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                                </small> </div>
                            <span  class=" fw-bold mt--1 d-block mb-0">غـيـل بـاوزيـر / الـصـالـحـيـة </span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center border-bottom py-3">
                        <img class="rounded-circle flex-shrink-0" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                        <div class="w-100 me-2">
                            <div class="d-flex w-100 justify-content-between align-items-center">
                                <h6 class="mb-0 m-0 p-0 ">خـالـد علي</h6>
                                <small class="mt-3 mb-0">
                                    <a class="btn btn-sm  fw-bold " href=""><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                                </small>  </div>
                            <span  class=" fw-bold mt--1 d-block mb-0"> عـدن / حـي الـراقـي</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-6 col-xl-4 mb-60">
                <div class="h-100 bg-secondary rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0 fw-bold">الـتـقـويـم</h6>
                       </div>
                    <div id="calender"></div>
                </div>
            </div>
            </div>
    </div>
    <!-- Widgets End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/platform/platform.blade.php ENDPATH**/ ?>