



<?php $__env->startSection('content'); ?>
    <!-- Sale & Revenue Start -->
    <div class="container-fluid pt-4 px-4" dir="ltr">
        <div class="row g-4">
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary1 rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-line fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2 fw-bold">عـدد الـمـنـاقـصـات</p>
                        <h6 class="mb-0"><?php echo e($tenderCount); ?></h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary1 rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-area fa-3x text-primary"></i>
                    <div class="ms-3 ">
                        <p class="mb-2 fw-bold"> قـيـد الأعــداد</p>
                        <h6 class="mb-0"><?php echo e($tenderstart); ?></h6>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary1 rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-bar fa-3x text-primary"></i>
                    <div class="ms-2">
                        <p class="mb-2 fw-bold">المناقصات الفعالة </p>
                        <h6 class="mb-0"><?php echo e($tenderactive); ?></h6>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary1 rounded d-flex align-items-center justify-content-between py-4 px-3">
                    <i class="fa fa-chart-pie fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2 fw-bold">المناقصات المنتهي</p>
                        <h6 class="mb-0"><?php echo e($tenderfinsh); ?></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Sale & Revenue End -->


    <!-- Recent Sales Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary1 text-center rounded p-4">
            <div class="d-flex align-items-center justify-content-between pb-2 ">
                <h6 class="mb-0 fw-bold">الـمـنـاقـصـات قـيـد الأنتـظـار</h6>
                <a href="<?php echo e(route('tender.index')); ?>" class="fw-bold">عــرض الـكـل</a>
            </div>
            <div class="table-responsive">
                <table class="table text-start table-striped table-borderless align-middle  table-hover mb-0 text-center">
                    <thead>
                        <tr class="text-white">
                            <th scope="col"> الـمـنـاقـصـة</th>

                            <th scope="col">الـمـعـد </th>
                            <th scope="col" class="w-25">عـمـلـيـات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $under): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="fw-bold"> <?php echo e($under->name); ?></td>
                                <td class="fw-bold"> <?php echo e($under->title); ?></td>
                                <td class="fw-bold ">
                                    <?php if($under->tenderDocuments()->exists()): ?>
                                        <a class="btn btn-sm  fw-bold" href="<?php echo e(route('notebook.show', $under->id)); ?>"><i
                                                class="fas fa-file-contract fw-bold  f-18"></i></a>
                                    <?php else: ?>
                                        <a class="btn btn-sm  fw-bold" href="<?php echo e(route('createnote', $under->id)); ?>"><i
                                                class="fa fa-address-book fw-bold  f-18"></i></a>
                                    <?php endif; ?>
                                    <a class="btn btn-sm  fw-bold"
                                        href="<?php echo e(route('tender.show', ['tender' => $under->id])); ?>"><i
                                            class="bi bi-info-circle fw-bold  f-18"></i></a>
                                    <a class="btn btn-sm  fw-bold"
                                        href="<?php echo e(route('tender.edit', ['tender' => $under->id])); ?>"><i
                                            class="bi bi-pencil-fill fw-bold  f-18"></i></a>
                                    <a class="btn btn-sm fw-bold delete-btn" data-bs-toggle="modal"
                                        data-bs-target="#myModal<?php echo e($under->id); ?>" data-id="<?php echo e($under->id); ?>"
                                        data-name="<?php echo e($under->id); ?>"><i
                                            class="fas fa-trash-alt fw-bold text-primary f-18"></i></a>
                                    
                                </td>
                            </tr>
                            <div style="margin-top: 15% !important" class="modal fade mt-5" id="myModal<?php echo e($under->id); ?>"
                                tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog ">
                                    
                                    <div class="modal-content  bg-secondary">
                                        <div class="modal-header border-0 d-flex justify-content-between w-100">
                                            <h6 class="modal-title pt-2" id="exampleModalLabel"> هــل تــريــد حــذف هـذا
                                                الـمـنـاقـصـة <?php echo e($under->name); ?>؟</h6>
                                            
                                        </div>
                                        <div class="modal-body border-0">
                                            <p>بالضغط على تأكيد سيتم حذف العنصر نهائياً.</p>
                                        </div>
                                        <div class="modal-footer border-0">
                                            <form action="<?php echo e(route('tender.destroy', $under->id)); ?>" method="post">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-primary px-4">تأكيد</button>
                                            </form>
                                            <button type="button" class="btn btn-secondary px-4"
                                                data-bs-dismiss="modal">إلغاء</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </table>
            </div>
        </div>
    </div>
    <!-- Recent Sales End -->


    <!-- Widgets Start -->
    <div style="margin-bottom: 70px !important" class="container-fluid pt-4 px-4 ">
        <div class="row g-4 mb-80">

            <div class="col-sm-12 col-md-6 col-xl-8">
                <div class="h-100 bg-secondary1 rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-0 ">
                        <h6 class="mb-0 fw-bold">الـمـقـاولـيـن</h6>
                        <a href="" class="fw-bold">عــرض الـكـل</a>
                    </div>
                    <div class="container-fluid pt-2 px-0  mb-3">
                        <div class="bg-secondary1 text-center rounded ">

                            <div class="table-responsive">
                                <table
                                    class="table table-striped table-borderless align-middle  table-hover mb-0 text-center">
                                    <thead>
                                        <tr class="text-white fs-5">
                                            <th scope="col">الـمـقـاول</th>
                                            <th scope="col">المناقصة</th>
                                            <th scope="col">عـمـلـيـات </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $TenderSubmit->tenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $tender->tenderApplicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    
                                                    <?php if($applicant->status === 0): ?>
                                                        <td class="fw-bold"><?php echo e($applicant->freelancer->name); ?> </td>

                                                        <td class="fw-bold"><?php echo e($tender->name); ?></td>
                                                       <td>
                                                            <?php echo e($applicant->id); ?>

                                                            <a class="btn btn-sm fw-bold"
                                                                href="<?php echo e(route('contractors.show', $applicant->id)); ?>"><i
                                                                    class="bi bi-info-circle fw-bold f-18"></i></a>
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div>

            <div class="col-sm-12 col-md-6 col-xl-4">
                <div class="h-100 bg-secondary1 rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <h6 class="mb-0 p-2 fw-bold">الـتـقـويـم</h6>
                    </div>
                    <div id="calender"></div>
                </div>
            </div>
        </div>
    </div>
    <!-- Widgets End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/munaqasatmloud/dashboard/tenant/tenant.blade.php ENDPATH**/ ?>