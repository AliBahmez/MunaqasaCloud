



<?php $__env->startSection('content'); ?>
<div  class="container-fluid  m-0 ">
    <div class="row align-items-center justify-content-center ">
        <div class="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4 p-0 " style="width: 40% !important ; ">
            <div class="bg-secondary rounded  p-sm-2 mt-4  " style="padding: 20px 50px !important ">
                <div class="text-center mb-4 "> 
                    <h6 class=" fs-5">اضــافــة مـسـتـخـدم</h6>
                 </div> 
                 <form method="POST" action="<?php echo e(route('account.back.users.store')); ?>" class="">
                    <?php echo csrf_field(); ?>
                    <input name="name" type="text" class="form-control myform-control py-2 m-0 my-3" id="floatingInput" placeholder="اسـم الـمـسـتـخـدم">
                    <input name="label" type="password" class="form-control myform-control py-2 m-0" id="floatingInput" placeholder="كـلـمـة الـمـرور">
                
                    <div class="d-flex align-items-center justify-content-between my-3">
                        <label class="form-check-label" for="exampleCheck1">دور الأولـى</label>
                        <input type="checkbox" name="role" class="form-check-input" id="exampleCheck1">
                    </div>
                    
                    <button type="submit" class="btn btn-primary px-3 w-100 my-2 fs-5">اضــافــة </button>
                </form>
                
                        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/account/users/add.blade.php ENDPATH**/ ?>