

<?php $__env->startSection('content'); ?>
    <h6 class="text-end mx-4 mt-3 fw-bold text-while f-18"> الـمـقـاولـيـن الـمـتـقـدمـيـن لـلـمـنـاقـصـة</h6>
    <div class="container-fluid pt-2 px-4  mb-3">
        <div class="bg-secondary1 text-center rounded p-4">

            <div class="table-responsive">
                <table class="table text-start align-middle table-striped table-borderless table-hover mb-0 text-center">
                    <thead>
                        <tr class="text-white fs-5">
                            <th scope="col">الـمـقـاول</th>
                            <th scope="col">المناقصة</th>
                            <th scope="col">عـمـلـيـات </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $TenderSubmit->tenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $tender->tenderApplicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php if($applicant->status === 0): ?>
                                        <td class="fw-bold"><?php echo e($applicant->freelancer->name); ?> </td>

                                        <td class="fw-bold"><?php echo e($tender->name); ?></td>

                                        <td>
                                            <a class="btn btn-sm fw-bold"
                                                href="<?php echo e(route('contractors.show', $applicant->id)); ?>"><i
                                                    class="bi bi-info-circle fw-bold f-18"></i></a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/munaqasatmloud/contractors/tenant/index.blade.php ENDPATH**/ ?>