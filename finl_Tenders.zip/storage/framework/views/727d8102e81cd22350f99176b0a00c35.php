

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between">
        <h6 class="text-end m-4 fw-blod">تـفـاصـيـل الـمـسـتـنـد </h6>
        <?php if($tender->state == 0): ?>
            <a class="btn btn-sm mybtn-secondary px-2 py-1 mx-5 mb-3 mt-4 p-0 fw-bold delete-btn" data-bs-toggle="modal"
                data-bs-target="#myModal12"><i class="fas fa-plus fw-bold text-white f-18"></i></a>
        <?php endif; ?>
    </div>
    <div style="margin-top: 3% !important; width: 100% !important;" class="modal fade  mt-5" id="myModal12" tabindex="-1"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog w-100 ">
            <div style="width: 140% !important" class="modal-content  bg-secondary1">
                <div class="bg-secondary1 border-0 text-center rounded p-4 pb-3 w-100 ">
                    <h4 class="pt-2">دفـتـر الـمـنـاقـصـة</h4>
                    <div class="table-responsive mt-5 ">
                        <div class="d-flex justify-content-between   text-center fw-bold text-white">
                            <p class="fw-bold px-3 m-0 text-end me-5 ">أدخل البنود ومواصفات عن المناقصة </p>
                        </div>

                        <form class="d-flex justify-content-center" action="<?php echo e(route('notebook.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div id="inputContainer" class="mx-5 p-0 w-100">
                                <div class="my-1 me-1 py-1">
                                    <input type="text" hidden value="<?php echo e($docmuents[0]->tender_id); ?>" name="item"
                                        id="">
                                    <input class="my-1 me-1 py-1 w-100 p-2 myform-control  rounded-1" type="text"
                                        name="technical_title[]" placeholder="أدخل الـبـنـد" required>
                                    <textarea class=" my-1 me-1 py-1 w-100 p-2 myform-control  rounded-1" name="technical_description[]" id=""
                                        cols="10" rows="3" placeholder="اكـتـب وصـف عـن الـبـنـد" required></textarea>
                                </div>
                            </div>


                    </div>
                    <div class=" p-0 d-flex justify-content-center">
                        <button type="submit" class="btn btn-sm mybtn-secondary fw-bold px-3 fs-6 m-2 mx-5 w-99"
                            href=""> اضـافـة </button>
                        </form>

                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <div class="container-fluid mb-80  px-4">
        <div class="bg-secondary1 text-center rounded p-4 pb-3">
            <div class="table-responsive">

                
                <table class="table text-start table-striped table-borderless align-middle  table-hover mb-0 text-center">
                    <thead>
                        <tr class="text-white">
                            <th style="width: 30% !important" scope="col ">الــبــنــود </th>
                            <th style="width: 60% !important" scope="col"> الــمــنــاقــصــة</th>
                            <?php if($tender->state == 0): ?>
                                <th scope="col">عــمــلــيــات</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $docmuents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docmuent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-3"><?php echo e($docmuent->technical_title); ?></td>
                                <td class="px-3"><?php echo e($docmuent->technical_description); ?></td>
                                <?php if($tender->state == 0): ?>
                                    <td class="fw-bold ">
                                        

                                        <a class="btn btn-sm  fw-bold" href="<?php echo e(route('notebook.edit', $docmuent->id)); ?>"><i
                                                class="bi bi-pencil-fill fw-bold  f-18"></i></a>
                                        <a class="btn btn-sm fw-bold delete-btn" data-bs-toggle="modal"
                                            data-bs-target="#myModal<?php echo e($docmuent->id); ?>" data-id="<?php echo e($docmuent->id); ?>"
                                            data-name="<?php echo e($docmuent->id); ?>"><i
                                                class="bi bi-trash fw-bold text-primary f-18"></i></a>
                                    </td>
                                <?php endif; ?>
                                <div style="margin-top: 15% !important" class="modal fade mt-5"
                                    id="myModal<?php echo e($docmuent->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog ">
                                        <div class="modal-content  bg-secondary1">
                                            <div class="modal-header border-0 d-flex justify-content-between w-100">
                                                <h6 class="modal-title pt-2" id="exampleModalLabel"> هــل تــريــد حــذف
                                                    هـذا الـمـتـسـنـد ؟</h6>
                                            </div>
                                            <div class="modal-body border-0">
                                                <p>بالضغط على تأكيد سيتم حذف الـمـتـسـنـد نهائياً.</p>
                                            </div>
                                            <div class="modal-footer border-0">
                                                <form action="<?php echo e(route('notebook.destroy', $docmuent->id)); ?>"
                                                    method="post">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn mybtn-secondary px-4">تأكيد</button>
                                                </form>
                                                <button type="button" class="btn btn-secondary px-4"
                                                    data-bs-dismiss="modal">إلغاء</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
            </div>
            <div class="mt-3 p-0 d-flex justify-content-between">

                <p></p>

                <a class="btn btn-sm btn-dark  px-4 fw-bold  m-2" href="<?php echo e(route('tender.index')); ?> ">رجـوع </a>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/munaqasatmloud/tenders/tenant/docmuentdetails.blade.php ENDPATH**/ ?>