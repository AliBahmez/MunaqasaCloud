


<?php $__env->startSection('content'); ?>
<h6 class="text-end mx-4 mt-3 fw-bold text-while f-18">  الأعــدادات</h6>
<div class="container-fluid pt-2 px-4  mb-3">
    <div class="bg-secondary text-center rounded p-4">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <h6 class="mb-0 fw-bold"></h6>
            <a class="btn btn-sm btn-primary fw-bold px-4 py-2 m-2" href="<?php echo e(route('platform.settings.add')); ?>">أضــافــة إعــداد</a>
           </div>
        <div class="table-responsive">
            <table class="table text-start align-middle table-bordered table-hover mb-0 text-center">
                <thead>
                    <tr class="text-white">
                        <th scope="col">الإسـم </th>
                        <th scope="col">الـقـيـمـة </th>
                        <th scope="col">عـمـلـيـات</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="fw-bold"></td>
                        <td class="fw-bold"></td>
                        <td class="fw-bold ">
                            <a class="btn btn-sm  fw-bold " href="<?php echo e(route('platform.settings.update')); ?>"><i class="bi bi-pencil-fill fw-bold  f-18"></i></a>
                            <a class="btn btn-sm fw-bold " href="<?php echo e(route('platform.settings.deletes')); ?>"><i class="bi bi-trash fw-bold text-primary f-18"></i></a>
                           
                            </td>
                    </tr>
              
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/platform/settings/index.blade.php ENDPATH**/ ?>