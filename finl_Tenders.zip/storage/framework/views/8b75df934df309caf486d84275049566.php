



<?php $__env->startSection('content'); ?>
<h6 class="text-end mx-4 mt-3  text-while f-18">  الأدوار</h6>
<nav class="mt-3 mx-4">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"></li>
      <li class="breadcrumb-item">الحسابات</li>
      <li class="breadcrumb-item active"><a href="<?php echo e(route('account.back.roles.index')); ?>">الأدوار</a></li>
    </ol>
  </nav>
  <div class=" mb-80 mb-3 w-100 text-center">
    <div class="w-100 ">

      <div class=" border-0  w-100 d-flex justify-content-center">
        <div class=" bg-secondary w-50 rounded-2 pt-3">
          <!-- Bordered Tabs -->
         
          <div class="pt-2">

            <div class="tab-pane fade show active profile-overview" id="profile-overview">
              <h4 class="card-title "><?php echo e($role->label); ?></h4>

              <hr>
              <h5 class="">الاذونات</h5>

              <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class=" text-center my-3">
                <div class="label "><?php echo e($permission->label); ?></div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

      </div>

    </div>
  </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/account/roles/show.blade.php ENDPATH**/ ?>