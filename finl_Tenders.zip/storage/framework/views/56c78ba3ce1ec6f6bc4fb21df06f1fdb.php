<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="utf-8">
    <title>مـنـاقـصـة كـلاد</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="<?php echo e(asset('img/favicon.ico')); ?>" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?php echo e(asset('lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css')); ?>" rel="stylesheet" />
    
    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

    <style>
        @font-face {
    font-family: Droid;
    src: url('<?php echo e(asset("font/Droid.Arabic.Kufi_DownloadSoftware.iR_.ttf")); ?>');
    src: url('<?php echo e(asset("font/Droid.Arabic.Kufi_DownloadSoftware.iR_.ttf")); ?>')format('truetype');
}
    *{
        font-family: 'Droid', 'sans-serif';
    }
    </style>
</head>

<body >
    <div class="container-fluid position-relative d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <div class="sidebar pe-4 pb-3">
            <nav class="navbar bg-secondary navbar-dark">
                <a href="index.html" class="navbar-brand mx-4 mb-3">
                    <h4 class="text-primary">
                        <i class="fas fa-balance-scale ms-2" aria-hidden="true"></i>مـنـاقـصـة كـــلاود</h4>
                        
                </a>
                <div class="d-flex align-items-center ms-4 mb-4">
                    <div class="position-relative">
                        <img class="rounded-circle" src="<?php echo e(asset('img/user.jpg')); ?>" alt="" style="width: 40px; height: 40px;">
                        <div class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1"></div>
                    </div>
                    <div class="me-3">
                        <h6 class="mb-0"> عـلـي بـاهـمـز</h6>
                        <span>مـنـصـة</span>
                    </div>
                </div>
                <div class="navbar-nav w-100">
                    <?php
                    $tenant = Account::getTenantName();
                  ?>
                  <?php if($tenant === "platform"): ?>
                  
                  
                        
                    
                    <ul class="w-100 m-0 p-0 list-unstyled">
                        <li>
                            <b   class="nav-item nav-link  fw-bold active"><i class="fa fa-tachometer-alt ms-2 "></i>الــمــنــصــة</b>
                        </li>
                        <?php
                            $permissions = array(
                                'account__manage_accounts',
                                'account__manage_users',
                                'account__list_users'
                            );
                            $hasPermission = Account::hasPermissions($permissions);
                        ?>
                        <?php if($hasPermission): ?>
                        <li>
                            <a href="<?php echo e(route('platform')); ?>" class="nav-item nav-link  fw-bold"><i class="bi bi-grid ms-2 "></i>لـوحـة الـتـحـكـم</a>
                        </li>
                            <li>
                                <div class="nav-item dropdown">
                                <a href="index.html" class="nav-item nav-link dropdown-toggle fw-bold " data-bs-toggle="dropdown"><i class="fas fa-key ms-2"></i>الـحـسـابـات</a>
                                <div class="dropdown-menu bg-transparent border-0 p-0 m-0 dropdown-menu-start text-end me-4 ">
                                    <a href="<?php echo e(route('account.back.roles.index')); ?>" class="nav-item nav-link w-75 ">
                                        <i class="fa fa-laptop ms-1"></i>
                                        الأدوار
                                    </a>
                                    <a href="<?php echo e(route('account.back.users.index')); ?>" class="nav-item nav-link w-75">
                                        <i class="fa fa-laptop ms-1"></i>
                                        المستخدمين
                                    </a>
                                    
                                  </div>
                                </div>
                               </li>
                               <?php endif; ?>
                               <li>
                                <div class="nav-item dropdown">
                                <a href="index.html" class="nav-item nav-link dropdown-toggle fw-bold " data-bs-toggle="dropdown"><i class="fas fa-map-marker-alt ms-2"></i>الـعـنـاويـن</a>
                                <div class="dropdown-menu bg-transparent border-0 p-0 m-0 dropdown-menu-start text-end me-4 ">
                                    <a href="<?php echo e(route('governorates')); ?>" class="nav-item nav-link w-75 ">
                                        <i class="fas fa-building ms-1"></i>
                                        الـمـحـافـظـات
                                    </a>
                                    <a href="<?php echo e(route('directorates')); ?>" class="nav-item nav-link w-75">
                                        <i class="fas fa-sitemap ms-1"></i>
                                        الـمـديـريـات
                                    </a>
                                    
                                  </div>
                                </div>
                               </li>
                              
                            

                               <li>
                                <a href="<?php echo e(route('foundations.index')); ?>" class="nav-item nav-link fw-bold">
                                    <i class="fas fa-university ms-2"></i>الـمـؤسـسـات
                                </a>
                                
                                    
                                 </li>
                                 <li>
                                    <a href="<?php echo e(route('contractor.index')); ?>" class="nav-item nav-link fw-bold">
                                        <i class="fas fa-hard-hat ms-2"></i> المقاولين
                                    </a>
                                </li>
                            <li>
                                <a href="" class="nav-item nav-link fw-bold"><i class="fas fa-envelope ms-2"></i>الــرســائــل</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('platform.settings')); ?>" class="nav-item nav-link fw-bold"><i class="fas fa-cogs ms-2"></i> الأعــدادات</a>
                            </li>
                           
                        </ul>
                        <?php endif; ?>
                       
                       <?php
                            $tenant = Account::getTenantName();
                        ?>
                        <?php if($tenant === "app"): ?>
                        <ul class="w-100 m-0 p-0 list-unstyled">
                            <li>
                             <b   class="nav-item nav-link  active fw-bold"><i class="fa fa-tachometer-alt ms-2 "></i>الـمـؤسـسـة</b>   
                            </li>
                            <?php
                            $permissions = array(
                                'account__manage_accounts',
                                'account__manage_users',
                                'account__list_users'
                            );
                            $hasPermission = Account::hasPermissions($permissions);
                        ?>
                        <?php if($hasPermission): ?>
                            <li>
                                <a href="<?php echo e(route('tenant.tenant')); ?>" class="nav-item nav-link  fw-bold"><i class="bi bi-grid ms-2 "></i>لـوحـة الـتـحـكـم</a>
                            </li>
                            <li>
                                <div class="nav-item dropdown">
                                <a href="index.html" class="nav-item nav-link dropdown-toggle fw-bold " data-bs-toggle="dropdown"><i class="fa fa-laptop ms-2"></i>الـحـسـابـات</a>
                                <div class="dropdown-menu bg-transparent border-0 p-0 m-0 dropdown-menu-start text-end me-4">
                                    <a href="<?php echo e(route('roles')); ?>" class="nav-item nav-link  w-75">
                                        <i class="fa fa-laptop ms-1"></i>
                                        الأدوار
                                    </a>
                                    <a href="<?php echo e(route('users')); ?>" class="nav-item nav-link w-75">
                                        <i class="fa fa-laptop ms-1"></i>
                                        المستخدمين
                                    </a>
                                    
                                  </div>
                                </div>
                               </li>
                               <?php endif; ?>
                               <li>
                               <a href="<?php echo e(route('tender.index')); ?>" class="nav-item nav-link  fw-bold " ><i class="fas fa-file-contract ms-2"></i>الـمـنـاقـصـات</a>
                               
                                
                               </li>
                              
                              <li>
                                <a href="<?php echo e(route('offers.index')); ?>" class="nav-item nav-link  fw-bold " ><i class="fas fa-tags ms-2"></i>الــعــروض</a>
                             </li>
                              <li>
                                <a href="<?php echo e(route('contractors.index')); ?>" class="nav-item nav-link  fw-bold " ><i class="fas fa-hard-hat ms-2"></i>الـمـقـاولـيـن</a>
                             </li>
                              <li>
                                <a href="<?php echo e(route('tenant.messages')); ?>" class="nav-item nav-link fw-bold"><i class="fas fa-envelope ms-2"></i>الــرســائــل</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('tenant.settings')); ?>" class="nav-item nav-link fw-bold"><i class="fas fa-cogs ms-2"></i> الأعــدادات</a>
                            </li>
                            
                            <li>
                                <b   class="nav-item nav-link  active fw-bold"><i class="fas fa-hard-hat ms-2 "></i>الـمـقـاول</b>
                             </li>
                            <li>
                                <a href="<?php echo e(route('freelancer.freelancer')); ?>" class="nav-item nav-link  fw-bold"><i class="bi bi-grid ms-2 "></i>لـوحـة الـتـحـكـم</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('tenders.index')); ?>" class="nav-item nav-link fw-bold"><i class="fas fa-hard-hat ms-2"></i> الـمـنـاقـصـات</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('frrelanceroffers.index')); ?>" class="nav-item nav-link fw-bold"><i class="fas fa-tags ms-2"></i> الــعــروض</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('mytenders.index')); ?>" class="nav-item nav-link fw-bold"><i class="fas fa-hard-hat ms-2"></i> مـنـاقـصـاتـي</a>
                            </li>
                        </ul>
                        <?php endif; ?>
                        
                </div>
            </nav>
        </div>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content position-relative">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-secondary navbar-dark sticky-top px-4 py-0">
                <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0">
                        <i class="fa fa-user-edit"></i>
                    </h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars "></i>
                </a>
                <form class="d-none d-md-flex  form-header">
                    <input class="form-control bg-dark border-0 w-100" type="search" placeholder="بــحــث ...">
                </form>
                <div class="navbar-nav align-items-center ms-auto mynav">
                    <div class="nav-item dropdown">

                    </div>
                    <div class="nav-item dropdown">
                        <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-chat-left-text fs-5 "></i>
                            <span class="badge bg-success badge-number position-absolute end-0">3</span>
                          </a>
                          <div class="dropdown-menu dropdown-menu1 dropdown-menu-end bg-secondary border-0 rounded-0 rounded-bottom m-0" dir="">
                         
                          
                              <a href="#" class="dropdown-item d-flex py-3 ">
                                <img height="50px" src="<?php echo e(asset('img/user.jpg')); ?>" alt="" class="rounded-circle  mx-2">
                                <div  class="p-0 m-0 w-100">
                                  <h6>مـؤسـسـة حـضـرمـوت </h6>
                                  <small  class="p-1 m-0 ">بالتعاون مع منصتكم واستخدام خدماتكم لتلبية احتياجاتنا</small>
                                  
                                </div>
                              </a>
                            
                           
                              <hr class="dropdown-divider">
                           
                              <a href="#" class="dropdown-item text-center py-2">الاطلاع على جميع الرسائل</a>

                        </div>
                    </div>
                    
                    <div class="nav-item dropdown mx-1">
                        <a href="#" class="nav-link " data-bs-toggle="dropdown">
                            
                            <i class="bi bi-bell me-lg-2 fs-5"></i>
                            <span class="badge bg-primary badge-number position-absolute start-60" >4</span>
                            
                        </a>
                        <div class="dropdown-menu dropdown-menu1 dropdown-menu-end bg-secondary border-0 rounded-0 rounded-bottom m-0" dir="">
                            
                            
                            <a href="#" class="dropdown-item d-flex justify-content-between py-3">
                                <div class="" >
                                <h6 class="fw-normal mb-0 text-end mb-1 ">مؤسسة العون</h6>
                                <small>طلب المصادقة البيانات</small>
                            </div>
                            <i class="bi bi-exclamation-circle text-warning fs-4"></i>
                            </a>
                            <hr class="dropdown-divider ">
                            <a href="#" class="dropdown-item d-flex justify-content-between py-3">
                                <div class="" >
                                <h6 class="fw-normal mb-0 text-end mb-1">مؤسسة العون</h6>
                                <small>طلب المصادقة البيانات</small>
                            </div>
                            <i class="bi bi-exclamation-circle text-warning fs-4"></i>
                            </a>
                            <hr class="dropdown-divider ">
                            <a href="#" class="dropdown-item d-flex justify-content-between py-3">
                                <div class="" >
                                <h6 class="fw-normal mb-0 text-end mb-1">مؤسسة العون</h6>
                                <small>طلب المصادقة البيانات</small>
                            </div>
                            <i class="bi bi-exclamation-circle text-warning fs-4"></i>
                            </a>
                            <hr class="dropdown-divider ">
                            <a href="#" class="dropdown-item text-center py-2">الاطلاع على جميع الإشعارات</a>
                        </div>
                    </div>
                     <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <img class="rounded-circle me-lg-2" src="<?php echo e(asset('img/user.jpg')); ?>" alt="" style="width: 40px; height: 40px;">
                            <span class="d-none d-lg-inline-flex px-1 fw-bold"> علي باهمز </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-secondary  border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">My Profile</a>
                            <a href="#" class="dropdown-item">Settings</a>
                            <form method="post" action="<?php echo e(route('account.back.signout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item d-flex align-items-center" href="#">
                                  <i class="bi bi-box-arrow-right ms-2"></i>
                                  <span>تسجيل الخروج</span>
                                </button>
                              </form>
                        </div>
                    </div> 
                </div>
            </nav>
            <!-- Navbar End -->

            <?php echo $__env->yieldContent('content'); ?>
            


            <!-- Footer Start -->
            <div class="container-fluid  px-4  mb-2 position-absolute bottom-0">
                <div class="bg-secondary rounded-top p-4 ">
                    <div class=" text-center">
                        
                            &copy; جميع الحقوق  <a href="#" class="px-1 fw-bold">مناقصـة كــلاود</a>  محفوظة.
                        
                        
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('lib/chart/chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/waypoints/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/tempusdominus/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/tempusdominus/js/moment-timezone.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>

    <!-- Template Javascript -->
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    
<script>
    // window.onload = function() {
    //   var dots = document.getElementById("dots");
    //   var moreText = document.getElementById("more");
    //   var btnText = document.getElementById("myBtn");
    
    //   moreText.style.display = "none";
    
    //   btnText.onclick = function() {
    //     if (dots.style.display === "none") {
    //       dots.style.display = "inline";
    //       btnText.innerHTML = " ...عـرض الـمـزيـد..."; 
    //       moreText.style.display = "none";
    //     } else {
    //       dots.style.display = "none";
    //       btnText.innerHTML = " ...عـرض الأقـل..."; 
    //       moreText.style.display = "inline";
    //     }
    //   };

    //   ****
    function toggleText() {
        var shortText = document.getElementById('shortText');
        var longText = document.getElementById('longText');
        var btnText = document.getElementById('myBtn');
    
        if (longText.style.display === 'none') {
            longText.style.display = 'inline';
            shortText.style.display = 'none';
            btnText.textContent = 'عـرض اقل...';
        } else {
            longText.style.display = 'none';
            shortText.style.display = 'inline';
            btnText.textContent = 'عـرض الـمـزيـد...';
        }
    }

    //   **********************************************
//     window.addEventListener('DOMContentLoaded', function() {
//   var canvas = document.getElementById('progressCanvas');
//   var context = canvas.getContext('2d');
//   var x = canvas.width / 2;
//   var y = canvas.height / 2;
//   var radius = 60;
//   var startAngle = -Math.PI / 2;
//   var endAngle = 0;
//   var counterClockwise = false;
//   var progress = 0; // Set progress value between 0 and 100

//   function drawProgress() {
//     context.clearRect(0, 0, canvas.width, canvas.height);

//     // Draw background circle
//     context.beginPath();
//     context.arc(x, y, radius, 0, 2 * Math.PI);
//     context.lineWidth = 10;
//     context.strokeStyle = '#000';
//     context.stroke();

//     // Draw progress arc
//     context.beginPath();
//     context.arc(x, y, radius, startAngle, endAngle, counterClockwise);
//     context.lineWidth = 10;
//     context.strokeStyle = '#EB1616'; // Set progress bar color
//     context.stroke();

//     // Display progress text
//     context.font = '24px Arial';
//     context.fillStyle = '#fff';
//     context.textAlign = 'center';
//     context.textBaseline = 'middle';
//     context.fillText("30 يـوم" , x, y);
//     // context.fillText('30');
//   }

  function animateProgress() {
    var progressToFill = progress / 100;
    endAngle = (2 * Math.PI) * progressToFill + startAngle;

    drawProgress();

    if (progress < 55) {
      progress++;
      requestAnimationFrame(animateProgress);
    }
  }

  animateProgress();
});
    
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>