



<?php $__env->startSection('content'); ?>
<div class="container-fluid m-0 ">
    <div class="row align-items-center justify-content-center " style="height: 73.5vh; ">
        <div class="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4 w-60 " >
            <div  class="bg-secondary rounded px-3 py-4  h-150  mx-3">
                <h4 class="mb-4">تأكيد الحذف</h4>
                <p class="text-center mb-4-3">هل أنت متأكد أنك تريد حذف هذه السجل <?php echo e($user->username); ?></p>
                 <div class="float-start d-flex ">
                    <form method="post" action="<?php echo e(route('account.back.users.destroy', $user->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                     
            
                        <!-- Delete Button -->
                        <button type="submit" class="btn btn-primary px-4" data-bs-toggle="modal" data-bs-target="#deleteModal">
                          حذف
                        </button>
                      </form>
                    <a class="btn btn-sm btn-dark fw-bold px-4 me-3" href="javascript:history.back()">إلــغــاء</a>

                 </div>
               </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/back/account/users/delete.blade.php ENDPATH**/ ?>