<?php if($paginator->lastPage() > 1): ?>
    <ul class="pagination">
        <li class="btn btn-large <?php echo e(($paginator->currentPage() == 1) ? 'disabled' : ''); ?>">
            <a href="<?php echo e($paginator->url(1)); ?>">البداية</a>
        </li>
        <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
            <li class="btn btn-large <?php echo e(($paginator->currentPage() == $i) ? 'active' : ''); ?>">
                <a href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a>
            </li>
        <?php endfor; ?>
        <li class="btn btn-large <?php echo e(($paginator->currentPage() == $paginator->lastPage()) ? 'disabled' : ''); ?>">
            <a href="<?php echo e($paginator->url($paginator->lastPage())); ?>">الأخير</a>
        </li>
    </ul>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\finl_Tenders\resources\views/common/pagination.blade.php ENDPATH**/ ?>