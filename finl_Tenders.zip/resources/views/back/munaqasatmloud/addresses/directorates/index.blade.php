@extends('layouts.back')



@section('content')
<h6 class="text-end mx-4 mt-3  text-while f-18">  الـمـديـريـات</h6>
<div class="container-fluid pt-2 px-4  mb-3">
    <div class="bg-secondary text-center rounded p-4">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <a href="" class="fw-bold"> </a>
            <a href="{{ route('directorates.add')}}" class="mb-0 fw-bold  text-white btn btn-sm btn-primary px-4 py-1">أضافة مـديـريـات</a>
        </div>
        <div class="table-responsive">
            <table class="table text-start align-middle table-bordered table-hover mb-0 text-center">
                <thead>
                    <tr class="text-white ">
                        <!-- <th scope="col"><input class="form-check-input" type="checkbox"></th> -->
                        <th scope="col">اسـم</th>
                        <th scope="col">عـنـوان</th>                  
                        <th scope="col">عـمـلـيـات</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="fw-bold"></td>
                        <td class="fw-bold"></td>                      
                        <td class="">
                          <a class="btn btn-sm  fw-bold " href="{{route('directorates.view')}}"><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                         <a class="btn btn-sm  fw-bold " href="{{route('directorates.update')}}"><i class="bi bi-pencil-fill fw-bold  f-18"></i></a>
                         <a class="btn btn-sm fw-bold " href="{{route('directorates.delete')}}"><i class="bi bi-trash fw-bold text-primary f-18"></i></a>
                       
                        </td>
                    </tr>
                    <tr>
                        <td class="fw-bold "> </td>
                        <td class="fw-bold"></td>                      
                        <td class="">
                            <a class="btn btn-sm  fw-bold " href="{{route('directorates.view')}}"><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                            <a class="btn btn-sm  fw-bold " href="{{route('directorates.update')}}"><i class="bi bi-pencil-fill fw-bold  f-18"></i></a>
                            <a class="btn btn-sm fw-bold " href="{{route('directorates.delete')}}"><i class="bi bi-trash fw-bold text-primary f-18"></i></a>
                            </td>
                    </tr>
                    <tr>
                        <td class="fw-bold"> </td>
                        <td class="fw-bold"></td>                      
                        <td class="">
                            <a class="btn btn-sm  fw-bold " href="{{route('directorates.view')}}"><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                            <a class="btn btn-sm  fw-bold " href="{{route('directorates.update')}}"><i class="bi bi-pencil-fill fw-bold  f-18"></i></a>
                            <a class="btn btn-sm fw-bold " href="{{route('directorates.delete')}}"><i class="bi bi-trash fw-bold text-primary f-18"></i></a>
                           </td>
                    </tr>
                    <tr>
                        <td class="fw-bold"></td>                      
                        <td class="fw-bold"> </td>
                        <td class="">
                            <a class="btn btn-sm  fw-bold " href="{{route('directorates.view')}}"><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                            <a class="btn btn-sm  fw-bold " href="{{route('directorates.update')}}"><i class="bi bi-pencil-fill fw-bold  f-18"></i></a>
                            <a class="btn btn-sm fw-bold " href="{{route('directorates.delete')}}"><i class="bi bi-trash fw-bold text-primary f-18"></i></a>
                          </td>
                         <tr>
                         <td class="fw-bold"> </td>
                         <td class="fw-bold"> </td>
                         <td>
                         <a class="btn btn-sm  fw-bold " href="{{route('directorates.view')}}"><i class="bi bi-info-circle fw-bold  f-18"></i></a>
                         <a class="btn btn-sm  fw-bold " href="{{route('directorates.update')}}"><i class="bi bi-pencil-fill fw-bold  f-18"></i></a>
                         <a class="btn btn-sm fw-bold " href="{{route('directorates.delete')}}"><i class="bi bi-trash fw-bold text-primary f-18"></i></a>
                           </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection