@extends('layouts.back')

@section('content')
<h6  class="text-end m-4  mb-0 fw-bold text-while f-18">تـفـاصـيـل الـمـديـريـة</h6>
<div class="container-fluid pt-4 px-4">
    <div class="bg-secondary text-center rounded p-4 pb-3">
        <div class="table-responsive">
            <table class="table text-end  align-middle table-bordered table-hover mb-0 ">
               
               <tr >
                <th class="px-3 text-white w-250">الإســم</th>
                <td class="px-3 "> </td>
               </tr>
               <tr>
                <th class="px-3 text-white">   الـعـنـوان </th>
                <td class="px-3 "></td>
               </tr>
             
                   </table>
        </div>
        <div class="mt-3 p-0 d-flex justify-content-between">
           <b></b>
            <a class="btn btn-sm btn-dark  px-3  m-2" href="{{route('directorates')}}">الرجوع الى الـمـديـريـة</a>
        </div>        
    </div>

</div>
    
@endsection