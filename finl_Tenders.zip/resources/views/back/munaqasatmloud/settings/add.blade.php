@extends('layouts.back')



@section('content')
<div  class="container-fluid my-3 m-0 ">
    <div class="row align-items-center justify-content-center ">
        <div class="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4 p-0 " style="width: 60% !important ; ">
            <div class="bg-secondary rounded  p-sm-2 mt-4  " style="padding: 20px 50px !important ">
                <div class="text-center mb-4 "> 
                    <h6 class=" fs-5">اضــافــة إعــداد</h6>
                 </div> 
                    <div class="my-3">
                        <label class="fw-bold text-white" for="">الإسـم </label>
                        <input type="text" class="form-control myform-control py-2 m-0 my-2" id="floatingInput" >
                    </div>
                    <div class="my-3">
                        <label class="fw-bold text-white" for="">الـقـيـمـة  </label>
                        <input type="text" class="form-control myform-control py-2 my-2" id="floatingInput" >
                    </div>
                    
                    
                       <button type="submit" class="btn btn-primary px-3 w-100 my-2 fs-5">اضــافــة </button>
                 </div>
        </div>
    </div>
</div>
@endsection